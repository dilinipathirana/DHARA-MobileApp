#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Create API of ML model using flask

'''
This code takes the JSON data while POST request an performs the prediction using loaded model and returns
the results in JSON format.
'''

# Import libraries
import numpy as np
import scraping
from flask import Flask, request, jsonify
#import pickle

app = Flask(__name__)

# Load the model
#model = pickle.load(open('fakemodelLSTM2.pkl','rb'))
#graph = tf.get_default_graph()

@app.route('/data',methods=['GET','POST'])
def results():
    #global graph
    #with graph.as_default():
        # Get the data from the POST request.
    data = scraping.scrape()
    val=data['\n              value            ']
    val=''.join(val)
    val=val.replace('\n','')
    v=val.strip()
    tm=data['\n              time            ']
    tm=''.join(tm)
    tm=tm.replace('\n','')
    t=tm.strip()

    Dict=[{"time":t,"value":v}]
    
        

    return jsonify(Dict)
    #return data

if __name__ == '__main__':
    #pp.debug=True
    app.run(port=5000, debug=False)


# In[ ]:





# In[ ]:




