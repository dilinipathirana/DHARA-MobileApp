#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Create API of ML model using flask

'''
This code takes the JSON data while POST request an performs the prediction using loaded model and returns
the results in JSON format.
'''

# Import libraries
import numpy as np
import tensorflow as tf
from flask import Flask, request, jsonify
import pickle

app = Flask(__name__)

# Load the model
model = pickle.load(open('fakemodelLSTM2.pkl','rb'))
graph = tf.get_default_graph()

@app.route('/api',methods=['GET','POST'])
def predict():
    global graph
    with graph.as_default():
        # Get the data from the POST request.
        data = {'id': 0.8}#request.get_json(force=True)
        arr=np.array( tuple(data.values()))
        darray=arr.reshape((1, len(arr), 1))

        # Make prediction using model loaded from disk as per the data.
        prediction = model.predict(darray)

        # Take the first value of prediction
        output =prediction.reshape(4,1)
        mydict=[{"hour1":output.item(0),"hour2":output.item(1),"hour3":output.item(2),"hour4":output.item(3)}]
        

    return jsonify(mydict)
    #return data

if __name__ == '__main__':
    #pp.debug=True
    app.run(port=5001, debug=False)


# In[ ]:





# In[ ]:




